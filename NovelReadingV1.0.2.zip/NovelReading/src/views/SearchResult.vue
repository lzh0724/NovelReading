<script setup>
import { inject, ref } from "vue";
import { showToast } from "vant";
import { useRouter } from "vue-router";
import { onMounted, onBeforeMount, nextTick, watchEffect, watch } from "vue";
const axios = inject("axios");
const router = useRouter();
console.log(router);
const book_key = ref(router.currentRoute.value.query.book_key);

const result_list = ref([]);
const value = ref(router.currentRoute.value.query.book_key);
watch(router.currentRoute, () => {
    router.go(0)
});
onMounted(() => {
  getBookInFo();
});
const getBookInFo = () => {
  // 向给定ID的用户发起请求
  axios.get("../../public/json/book_list.json").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      const book_list = data.data.books.books_list;
      for (let index = 0; index < book_list.length; index++) {
        if (book_list[index].name.includes(book_key.value)) {
          result_list.value.push(book_list[index]);
        }
      }
      console.log(result_list.value);
    });
  });
};

defineProps({
  msg: String,
});
const onClickLeft = () => {
  router.go(-1);
};
const onSearch = (val) => {
  router.push({
    path: `/result/:id=${val}`,
    query: { book_key: val },
  });
};
const ToBookInfo = (id)=>{
  router.push({
    path: `/books/:id=${id}`,
    query: { bookid: id },
  });
}
</script>

<template>
  <div id="index">
    <van-nav-bar
      @click-left="onClickLeft"
      title="搜索结果"
      left-text="返回"
      left-arrow
    >
    </van-nav-bar>
    <div class="search-box">
      <form action="/">
        <van-search
          v-model="value"
          show-action
          shape="round"
          placeholder="请输入书名"
          background="white"
          @search="onSearch"
          @cancel="onCancel"
        />
      </form>
    </div>

    <div class="result-box">
      <div @click="ToBookInfo(item.id)" class="result" v-for="(item, index) in result_list" :key="index">
        <div class="book-img-box">
          <img class="book-img" :src="item.url" alt="" />
        </div>
        <div class="book-text-box">
          <div class="book-name">
            {{ item.name }}
          </div>
          <div class="book-classify">
            {{ item.classify }}
          </div>
          <div class="book-synopsis">
            {{ item.synopsis }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.result {
  display: flex;
  width: 90%;
  margin: 20px auto;
  padding: 10px;
  background-color: white;
  border-radius: 15px;
}
.book-img-box {
  flex: 1.1;
  height: 110px;
  overflow: hidden;
  border-radius: 6px;
}
.book-text-box {
  flex: 3;
  letter-spacing: 1px;
  padding-left: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.book-name {
  font-size: 18px;
  color: red;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 1;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.result-box {
}
.book-classify {
  color: rgb(144, 144, 144);
  font-size: 14px;
}
.book-synopsis {
  color: rgb(144, 144, 144);
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.book-img {
  width: 100%;
}
.search-box {
}
</style>
