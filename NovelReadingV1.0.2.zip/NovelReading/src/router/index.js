import { createRouter, createWebHistory, createWebHashHistory } from 'vue-router'
import search from '../views/Search.vue'
import bookinfo from "../views/BookInfo.vue"
import book_list from "../views/SearchResult.vue"
const routes = [
  {
    path: '/',
    name: 'home',
    component: () => import('../views/index.vue'),
    meta: {
      showTab: true
    },
  },
  {
    path: '/bookshelf',
    name: 'bookshelf',
    component: () => import('../views/BookShelf.vue'),
    meta: {
      showTab: true
    },
  },
  {
    path: '/stack',
    name: 'stack',
    component: () => import('../views/Stack.vue'),
    meta: {
      showTab: true
    },
  },
  {
    path: '/mine',
    name: 'mine',
    component: () => import('../views/Mine.vue'),
    meta: {
      showTab: true
    },
  },
  {
    path: "/search",
    name: "search",
    component: search,
  },
  {
    path: "/books/:id(.*)*",
    name: "bookinfo",
    component: bookinfo,
  },
  {
    path: "/result/:key(.*)*",
    name: "result",
    component: book_list,
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})
router.beforeEach((to, from, next) => {
  next()
})
export default router
