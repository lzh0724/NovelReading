<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
const router = useRouter();

defineProps({
  msg: String,
});
const ClickBar = (key) => {
  console.log(key);
};
const active = ref(0);
//初始化icon数组 
const icon_list = ref({
  bookshelf: {
    default: "../../public/icon/bar-icon/bookshelf.png",
    active: "../../public/icon/bar-icon/bookshelf-active.png",
  },
  mine: {
    default: "../../public/icon/bar-icon/mine.png",
    active: "../../public/icon/bar-icon/mine-active.png",
  },
  stack: {
    default: "../../public/icon/bar-icon/stack.png",
    active: "../../public/icon/bar-icon/stack-active.png",
  },
});
</script>

<template>
  <div id="Bar">
    <van-tabbar
      @click="ClickBar(active)"
      route
      v-model="active"
      v-if="$route.meta.showTab"
    >
      <van-tabbar-item to="/" icon="home-o"> 首页 </van-tabbar-item>

      <van-tabbar-item to="/bookshelf">
        <span>书架</span>
        <template #icon="props">
          <img
            :src="
              props.active
                ? icon_list.bookshelf.active
                : icon_list.bookshelf.default
            "
          />
        </template>
      </van-tabbar-item>

      <van-tabbar-item to="/stack" icon="friends-o">
        <span>书库</span>
        <template #icon="props">
          <img
            :src="
              props.active ? icon_list.stack.active : icon_list.stack.default
            "
          />
        </template>
      </van-tabbar-item>

      <van-tabbar-item dot="true" to="/mine" icon="friends">
        <span>我的</span>
        <template #icon="props">
          <img
            :src="props.active ? icon_list.mine.active : icon_list.mine.default"
          />
        </template>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<style scoped>
</style>
