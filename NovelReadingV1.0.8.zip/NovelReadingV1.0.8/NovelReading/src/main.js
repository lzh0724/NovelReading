import { createApp } from 'vue'

import './style.css'
import App from './App.vue'
import router from "./router/index"
import Vant from "vant"
import "vant/lib/index.css"
// 引入模块后自动生效
import '@vant/touch-emulator';
// px2rem 自适应
import 'lib-flexible'
import axios from 'axios'
import VueAxios from 'vue-axios'
axios.defaults.baseURL = 'http://localhost:8081'
const app = createApp(App)
app.use(Vant)
app.use(router)
// .use(VueAxios, axios)
// .provide('axios', app.config.globalProperties.axios)
app.use(VueAxios, axios)
app.provide('axios', app.config.globalProperties.axios)
app.mount('#app')

