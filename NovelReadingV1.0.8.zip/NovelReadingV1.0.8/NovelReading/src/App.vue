<script setup>
import Bar from "./components/Bar.vue";
import { onMounted } from "vue";
// import {ref} from "ref"
const test = () => {
  console.log(this);
};

</script>

<template>
  <div id="app">
    <router-view></router-view>

    <Bar msg="Vite + Vue" />
  </div>
</template>

<style scoped>
</style>
