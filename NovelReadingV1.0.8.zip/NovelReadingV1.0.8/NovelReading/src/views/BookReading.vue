<script setup>
import { useRouter } from "vue-router"; //引入路由
import { inject, ref, watch } from "vue";
import { onMounted, onBeforeMount, nextTick } from "vue"; //引入生命周期,nextTick
import { showToast, closeToast, showLoadingToast } from "vant";
const show = ref(false);
const chapterlist = ref([]);
const axios = inject("axios"); //初始化axios
console.log(axios);
const router = useRouter(); //初始化路由
//监听路由变化，路由变化刷新页面
watch(router.currentRoute, () => {
  closeToast();
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  router.go(0);
  // is_Loading.value = false;
});
//生命周期监听
onMounted(() => {
  nextTick(() => {
    closeToast();
  });
});
const book_id = router.currentRoute.value.query.bookid; //接收路由传来的书的id
const title = ref(""); //初始化章节名字
const text = ref([]); //初始化文章数组
const chapterindex = ref(0); //初始化章节下标
const chapterlength = ref(0); //初始化章节目录总长度
//获取数据
const getBookInFo = () => {
  // is_Loading.value = true;
  // 向给定ID的用户发起请求
  axios.get("http://localhost:3000/books").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      text.value =
        data.data.book_text[0].context[chapterindex.value].text.split("*n");
      title.value =
        "第" +
        (chapterindex.value + 1) +
        "章" +
        "   " +
        data.data.book_text[0].context[chapterindex.value].name;
      chapterindex.value =
        data.data.book_text[0].context[chapterindex.value].id;
      chapterlength.value = data.data.book_text[0].context.length;
      for (let index = 0; index < chapterlength.value; index++) {
        chapterlist.value.push(data.data.book_text[0].context[index].name);
      }
    });
  });
};

//切换章节
const ChangeChapter = (flag,index) => {
    //flag作为标志,flag=1则下一章,flag=-1则上一章,flag = 0则跳转index所指章节
  closeToast();
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  //若是点击了上一章
  if (flag === -1) {
    //不是第一章的情况
    if (chapterindex.value > 0) {
      axios.get("http://localhost:3000/books").then(function (data) {
        // 处理成功情况
        nextTick(() => {
          //下标减1
          chapterindex.value--;
          //文本数据赋值
          text.value =
          //遇到*n分段
            data.data.book_text[0].context[chapterindex.value].text.split("*n");
          title.value =
            "第" +
            (chapterindex.value + 1) +
            "章" +
            "   " +
            data.data.book_text[0].context[chapterindex.value].name;
          //赋值成功关闭提示
          closeToast();
        });
      });
    } else {
      //已经是第一章的情况
      showToast("已经是第一张了！");
    }
  } else if (flag === 1) {
    //点击下一章的情况
    if (chapterindex.value < chapterlength.value - 1) {
      axios.get("http://localhost:3000/books").then(function (data) {
        // 处理成功情况
        nextTick(() => {
          chapterindex.value++;
          text.value =
            data.data.book_text[0].context[chapterindex.value].text.split("*n");
          title.value =
            "第" +
            (chapterindex.value + 1) +
            "章" +
            "   " +
            data.data.book_text[0].context[chapterindex.value].name;
          closeToast();
        });
      });
    } else {
      showToast("已经是最后一章了！");
    }
  } else if(flag === 0) {
    //点击目录的情况，转到index的章节
    axios.get("http://localhost:3000/books").then(function (data) {
      // 处理成功情况
      nextTick(() => {
        chapterindex.value = index;
        text.value =
          data.data.book_text[0].context[chapterindex.value].text.split("*n");
        title.value =
          "第" +
          (chapterindex.value + 1) +
          "章" +
          "   " +
          data.data.book_text[0].context[chapterindex.value].name;
        closeToast();
      });
    });
  }
  //页面回到最上方
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
};

//点击目录，选中章节
const ClickChapterList = (index) => {
  ChangeChapter(0,index);
  show.value = false;
};

//回退上一页面
const onClickLeft = () => {
  router.go(-1);
};
//点击下一章
const NextChapter = () => {
  ChangeChapter(1);
};
//点击上一章
const LastChapter = () => {
  ChangeChapter(-1);
};
//点击取消收藏
const ClickDown = () => {
  closeToast();
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });

  axios.get("http://localhost:3000/books").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      var book = data.data;
      var flag = false;
      var list = [];
      list = book.mine_books;
      let i = 0;
      let index;
      list.forEach((element) => {
        if (element.id === book_id) {
          flag = true;
          index = i;
        }
        i++;
      });
      if (flag) {
        book.mine_books.splice(index, 1);
        axios
          .put("http://localhost:3000/books", book)
          .then((res) => {
            console.log("成功", res);
            getBookInFo();

            closeToast();
            showToast("取消收藏成功");
          })
          .catch((error) => {
            console.log("失败", error);
          });
      } else {
        closeToast();
        showToast("还未收藏本书");
      }
    });
  });
};
//点击目录
const ClickDirectory = () => {
  closeToast();
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });

  show.value = true;

  closeToast();
};
//执行函数
getBookInFo();
</script>

<template>
  <div id="BookReading">
    <div class="nav-bar">
      <van-nav-bar
        @click-left="onClickLeft"
        :title="title"
        left-text="返回"
        left-arrow
      >
      </van-nav-bar>
    </div>

    <van-popup
      v-model:show="show"
      position="left"
      :style="{ width: '70%', height: '100%' }"
    >
      <div class="chapterlist-box">
        <p
          v-for="(item, index) in chapterlist"
          :key="index"
          class="chapterlist"
          @click="ClickChapterList(index)"
        >
          <span> 第{{ index + 1 }}章 </span>
          <span class="chapter-name">
            {{ item }}
          </span>
        </p>
      </div>
    </van-popup>

    <div class="box">
      <p class="context-box" v-for="(item, index) in text" :key="index">
        <span class="context">
          {{ item }}
        </span>
      </p>
    </div>
    <van-action-bar>
      <van-action-bar-icon
        icon="../../public/icon/book-info-icon/down_directory.png"
        text="目录"
        @click="ClickDirectory()"
      />
      <van-action-bar-icon
        icon="../../public/icon/book-info-icon/down_down.png"
        text="取消收藏"
        @click="ClickDown()"
      />
      <van-action-bar-button
        @click="LastChapter()"
        color="#be99ff"
        type="warning"
        text="上一章"
      />
      <van-action-bar-button
        @click="NextChapter()"
        color="#7232dd"
        type="danger"
        text="下一章"
      />
    </van-action-bar>
    <van-back-top right="2vw" bottom="10vh" />
  </div>
</template>
<style scoped>
.chapter-name {
  margin-left: 10px;
}
.chapterlist-box {
  padding: 10px;
}
.chapterlist {
  font-size: 16px;
  margin: 10px;
}
.footer-button {
  height: 100%;
}
.footer-box {
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 50px;
  background-color: white;
}
.box {
  padding: 50px 0;
}
.nav-bar {
  position: fixed;
  width: 100%;
  top: 0;
}
.context-box {
  width: 90%;
  margin: 20px;
}
.context {
  font-size: 18px;
}
#BookReading {
  background-color: rgb(241, 237, 228) !important;
}
</style>
