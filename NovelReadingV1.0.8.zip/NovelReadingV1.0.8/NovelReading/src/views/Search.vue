<script setup>
import { ref,nextTick,onMounted } from "vue";
import { showToast, closeToast, showLoadingToast } from "vant";

import {useRouter} from 'vue-router'
let is_Loading = ref(false);

defineProps({
  msg: String,
});
onMounted(()=>{
  nextTick(() => {
    closeToast();
  });
})
const history_search_list = [
  {
    name: "以我手足换手足",
  },
  {
    name: "我是",
  },
  {
    name: "韩溢洁",
  },
  {
    name: "的",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
  {
    name: "亲生父亲",
  },
];
const trending_search_list = [
  { name: "病娇" },
  { name: "女尊" },
  { name: "韩溢洁" },
  { name: "魔法少女" },
  { name: "重生之成为韩溢洁的父亲" },
  { name: "黑化" },
  { name: "嫁人" },
  { name: "血族" },
  { name: "变身" },
  { name: "被退婚了" },
];
const trending_books_list = [
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
  { name: "重生之成为韩溢洁父亲" },
];
const router = useRouter();

const onClickRight = () => showToast("按钮");
const onClickLeft = ( )=>{
  router.go(-1)
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
}
const value = ref("");
const onSearch = (val) => {
  router.push({
    path: `/result/:id=${val}`,
    query: { book_key: val},
  });
  setTimeout(() => {
  router.go(0);
  }, 0);
};
const onCancel = () => showToast("取消");
</script>

<template>
  <div id="stack">
    <div class="loading-box">
      <van-loading class="loading" v-show="is_Loading" type="spinner" color="#1989fa" />
    </div>
    <van-nav-bar
    @click-left="onClickLeft" title="搜索" left-text="返回" left-arrow> </van-nav-bar>
    <div class="search-box">
      <form action="/">
        <van-search
          v-model="value"
          show-action
          shape="round"
          placeholder="请输入书名"
          background="white"
          @search="onSearch"
          @cancel="onCancel"
        />
      </form>
    </div>

    <div class="search-box">
      <div class="title">
        <img class="icon-img" src="../../public/icon/history-2.png" alt="" />
        历史搜索
      </div>
      <div class="keyword-search-box">
        <div
          class="keyword-search"
          @click="onSearch(item.name)" 

          v-for="(item, index) in history_search_list"
          :key="index"
        >
          {{ item.name }}
        </div>
      </div>
    </div>

    <div class="search-box">
      <div class="title">
        <img class="icon-img" src="../../public/icon/trending.png" alt="" />
        热搜关键词
      </div>
      <div class="keyword-search-box">
        <div
          class="keyword-search"
          v-for="(item, index) in trending_search_list"
          :key="index"
          @click="onSearch(item.name)" 
        >
          {{ item.name }}
        </div>
      </div>
    </div>

    <div class="search-box">
      <div class="title">
        <img class="icon-img" src="../../public/icon/trending.png" alt="" />
        热搜作品
      </div>
      <div class="trending-books-box">
        <div
          class="trending-books"
          v-for="(item, index) in trending_books_list"
          :key="index"
          @click="onSearch(item.name)" 

        >
          <div class="ranking">{{ index + 1 }}</div>
          <div class="books-name">
            {{ item.name }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.loading-box{
  position:fixed;
  top: 50%;
  left: 50%;
  z-index: 10;
}
.books-name {
  font-size: 16px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  -o-text-overflow: ellipsis;
  letter-spacing: 1px;
  color: rgb(100, 100, 100);
}
.trending-books-box > :first-child > .ranking {
  background-color: red;
}
.trending-books-box > :nth-of-type(2) > .ranking {
  background-color: rgb(255, 115, 0);
}
.trending-books-box > :nth-of-type(3) > .ranking {
  background-color: rgb(255, 204, 0);
}
.ranking {
  background-color: #f1f1f1;
  width: 30px;
  text-align: center;
  font-size: 16px;
  border-radius: 4px;
  margin-right: 6px;
}
.trending-books {
  display: flex;
  width: 47%;
  margin: 10px 4px;
}
.trending-books-box {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.keyword-search {
  padding: 6px;
  margin: 5px;
  font-size: 13px;
  background-color: #f1f1f1;
  border-radius: 12px;
  max-width: 130px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  -o-text-overflow: ellipsis;
}
.keyword-search-box {
  display: flex;
  flex-wrap: wrap;
}
.icon-img {
  width: 6%;
  margin-right: 4px;
}
.title {
  font-size: 18px;
  display: flex;
  align-items: center;
  letter-spacing: 1px;
}
.search-box {
  background-color: white;
  width: 90%;
  margin: 10px auto;
  padding: 10px;
  border-radius: 10px !important;
  max-height: 160px;
  overflow: scroll;
}
</style>
