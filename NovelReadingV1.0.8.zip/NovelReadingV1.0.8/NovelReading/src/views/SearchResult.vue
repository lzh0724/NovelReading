<script setup>
import { inject, ref } from "vue";
import { showToast, closeToast, showLoadingToast } from "vant";
import { useRouter } from "vue-router";
import { onMounted, onBeforeMount, nextTick, watchEffect, watch } from "vue";
//加载图标初始化  （并没有用到）
let is_Loading = ref(false);
//axios引入初始化
const axios = inject("axios");
//路由初始化
const router = useRouter();
console.log(router);
//接收路由传来的小说关键字
const book_key = ref(router.currentRoute.value.query.book_key);
//搜索结果初始化
const result_list = ref([]);
//传来的小说关键字作为搜索框的值
const value = ref(router.currentRoute.value.query.book_key);

//监控路由变化
watch(router.currentRoute, () => {
  //路由变化则刷新本页面
  router.go(0);
  //出现加载图标
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
});
//生命周期
onMounted(() => {
  //获取数据
  getBookInFo();
});
//获取数据
const getBookInFo = () => {
  closeToast();

  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  // 向给定ID的用户发起请求
  axios.get("http://localhost:3000/books").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      const book_list = data.data.books_list;
      for (let index = 0; index < book_list.length; index++) {
        //进入小说总数组查找包含关键词的小说书名，若包含，则进入结果数组
        if (book_list[index].name.includes(book_key.value)) {
          result_list.value.push(book_list[index]);
        }
      }
      console.log(result_list.value);
      //函数完成，关闭加载图标
      closeToast();
    });
  });
};

defineProps({
  msg: String,
});
const onClickLeft = () => {
  router.go(-1);
};
//再次搜索
const onSearch = (val) => {
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  router.push({
    path: `/result/:id=${val}`,
    query: { book_key: val },
  });
};
//点击书籍，进入小说详情页面
const ToBookInfo = (id) => {
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  router.push({
    path: `/books/:id=${id}`,
    query: { bookid: id },
  });
};
</script>

<template>
  <div id="index">
    <div class="loading-box">
      <van-loading
        class="loading"
        v-show="is_Loading"
        type="spinner"
        color="#1989fa"
      />
    </div>
    <van-nav-bar
      @click-left="onClickLeft"
      title="搜索结果"
      left-text="返回"
      left-arrow
    >
    </van-nav-bar>
    <div class="search-box">
      <form action="/">
        <van-search
          v-model="value"
          show-action
          shape="round"
          placeholder="请输入书名"
          background="white"
          @search="onSearch"
          @cancel="onCancel"
        />
      </form>
    </div>

    <div class="result-box">
      <div
      
        @click="ToBookInfo(item.id)"
        class="result"
        v-for="(item, index) in result_list"
        :key="index"
      >
        <div class="book-img-box">
          <img class="book-img" :src="item.url" alt="" />
        </div>
        <div class="book-text-box">
          <div class="book-name">
            {{ item.name }}
          </div>
          <div class="book-classify">
            {{ item.classify }}
          </div>
          <div class="book-synopsis">
            {{ item.synopsis }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

.loading-box {
  position: fixed;
  top: 50%;
  left: 50%;
  z-index: 10;
}
.result {
  display: flex;
  width: 90%;
  margin: 20px auto;
  padding: 10px;
  background-color: white;
  border-radius: 15px;
}
.book-img-box {
  flex: 1.1;
  height: 110px;
  overflow: hidden;
  border-radius: 6px;
}
.book-text-box {
  flex: 3;
  letter-spacing: 1px;
  padding-left: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.book-name {
  font-size: 18px;
  color: red;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 1;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.result-box {
}
.book-classify {
  color: rgb(144, 144, 144);
  font-size: 14px;
}
.book-synopsis {
  color: rgb(144, 144, 144);
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.book-img {
  width: 100%;
}
.search-box {
}
</style>
