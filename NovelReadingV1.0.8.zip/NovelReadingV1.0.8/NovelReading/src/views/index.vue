<script setup>
import { ref,onMounted } from "vue";
import { showToast } from "vant";


onMounted(()=>{
let mp3 = new Audio("/public/video/原神，启动！.mp3"); // 创建音频对象
mp3.pause()
showToast("原神，启动！")

setTimeout(() => {
mp3.play(); // 播放
  
}, 100);


})
defineProps({
  msg: String,
});
const onClickRight = () => showToast("按钮");

</script>

<template>
  <div id="index">
    <van-nav-bar title="首页" right-text="按钮" @click-right="onClickRight" />
    
    
  </div>
</template>

<style scoped>

</style>
