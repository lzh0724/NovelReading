import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    index:'0',
    book_list:[]
  },
  getters: {
  },
  mutations: {
    updateFullLoading(state, status){
      state.fullscreenLoading = status
    }
  },
  actions: {
  },
  modules: {
  }
})
