<script setup>
import { ref } from "vue";
import { showToast } from "vant";

defineProps({
  swiper_img_list: Array,
});
const onClickRight = () => showToast("按钮");
const swiperChange = (index) => {};

</script>

<template>
  <div id="swiper">
    <div class="swiper-box">
        <!-- <div class="blur-swiper">
          <img class="blur-img" :src="images[swiper_index]" alt="" />
        </div> -->
        <div style="">
          <van-swipe
            indicator-color="white"
            class="vant-swiper"
            :autoplay="3000"
            lazy-render
            @change="swiperChange"
          >
            <van-swipe-item
              v-for="(image, index) in swiper_img_list"
              :key="index"
              style="display: flex"
            >
              <div class="blur-swiper">
                <img class="blur-img" :src="image" alt="" />
              </div>
              <img class="swiper-img" :src="image" />
            </van-swipe-item>
          </van-swipe>
        </div>
      </div>
  </div>
</template>

<style scoped>
.blur-img {
    width: 100%;
    position: relative;
    filter: blur(10px);
    z-index: -1;
  }
  .blur-swiper {
    position: absolute;
  }
  .swiper-img {
    width: 80%;
    height: 80%;
    border-radius: 10px;
    margin: auto;
  }
  .vant-swiper {
    height: 200px;
  }
  .swiper-box {
    width: 100%;
    height: 100%;
    margin: 0 auto;
  }
</style>
