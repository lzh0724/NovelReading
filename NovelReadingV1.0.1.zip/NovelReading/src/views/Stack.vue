<script setup>
import { ref,onMounted,nextTick } from "vue";
import { showToast } from "vant";
import { useRouter } from "vue-router";
import swiper from "../components/swiper.vue";
import { inject } from "vue";
const axios = inject("axios");

defineProps({
  msg: String,
});
const onClickRight = () => showToast("按钮");
const images = [
  "../../public/swiper-img/1.jpg",
  "../../public/swiper-img/2.jpg",
  "../../public/swiper-img/3.jpg",
];
const to_orther_list = [
  { name: "今日更新", url: "../../public/icon/renew.png" },
  { name: "精选专区", url: "../../public/icon/selected.png" },
  { name: "排行榜", url: "../../public/icon/ranking.png" },
  { name: "分类", url: "../../public/icon/classification.png" },
  { name: "书单", url: "../../public/icon/booklist.png" },
  { name: "日轻", url: "../../public/icon/book.png" },
];
const recommend_book_list = [
  {
    id: "0",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "1",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "2",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "3",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "4",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "5",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "6",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "7",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/bck-img-2.jpg",
    classify: "异世界/无敌/日常",
  },
];
const boutique_book_list = [
  {
    id: 11,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/1.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
  {
    id: 12,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/2.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
  {
    id: 13,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/3.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
];
const router = useRouter();
const ToSearch = () => {
  router.push({ path: "/search" });
};
const onClickLeft = () => {
  router.go(-1);
};
const ToBookInfo = (id) => {
  console.log(id);
  // books_list.find((object) => object.id === id)
  console.log(books_list);
  router.push({
    path: `/books/:id=${id}`,
    query: { bookid: id},
  });
};
var books_list = [];
const getBookInFo = () => {
  // 向给定ID的用户发起请求
  axios.get("../../public/json/book_list.json").then(function (data) {
    // 处理成功情况
    books_list.push(data.data.books.books_list);
    console.log(books_list[0]);
  });
};
getBookInFo();
onMounted(() => {
  nextTick(() => {
    console.log(books_list)
  })
});
// ref(swiperChange)
</script>

<template>
  <div id="stack">
    
    <van-nav-bar
      @click-left="onClickLeft"
      title="书库"
      left-text="返回"
      left-arrow
    >
      <template #right>
        <van-icon @click="ToSearch" name="search" size="18" />
      </template>
    </van-nav-bar>

    <swiper :swiper_img_list="images"></swiper>
    <div class="to-order-box">
      <div
        class="to-order-item"
        v-for="(item, index) in to_orther_list"
        :key="index"
      >
        <div class="to-order-img-box">
          <img class="to-order-img" :src="item.url" alt="" />
        </div>
        <div class="to-order-text">
          {{ item.name }}
        </div>
      </div>
    </div>

    <div style="background-color: white; border-radius: 26px 26px 0 0">
      <div style="padding: 0 10px 10px 10px; min-height: 520px">
        <div>
          <img class="ad-img" src="../../public/book-img/ad.jpg" alt="" />
        </div>
        <div class="wind-vane">人气风向标</div>
        <div class="recommend">
          <div
            class="recommend-box"
            @click="ToBookInfo(item.id)"
            v-for="(item, index) in recommend_book_list"
            :key="index"
          >
            <div class="recommend-book-img-box">
              <img class="recommend-book-img" :src="item.url" alt="" />
            </div>
            <div class="recommend-book-name">
              {{ item.name }}
            </div>
            <div class="recommend-book-classify">
              {{ item.classify }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <div class="boutique-box">
        <div class="boutique-title">今日精品更新</div>
        <div
          class="boutique-item-box"
          v-for="(item, index) in boutique_book_list"
          :key="index"
          @click="ToBookInfo(item.id)"
        >
          <div class="boutique-img-box">
            <img class="boutique-img" :src="item.url" alt="" />
          </div>
          <div class="boutique-item">
            <div class="boutique-line">
              <span class="boutique-name">
                {{ item.name }}
              </span>
              <span class="boutique-popularity">
                人气：{{ item.popularity }}W+
              </span>
            </div>

            <div class="boutique-classify">
              {{ item.classify }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.boutique-title {
  width: 90%;
  margin: 0px auto;
  padding: 15px 0 10px 0;
  font-size: 20px;
  font-weight: 800;
  letter-spacing: 2px;
}
.boutique-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 6px;
}
.boutique-classify {
  font-size: 12px;
  color: rgb(143, 143, 143);
  padding-top: 10px;
}
.boutique-item {
  width: 90%;
  margin: 0 auto;
}
.boutique-popularity {
  font-size: 12px;
  color: rgb(143, 143, 143);
}
.boutique-name {
  font-size: 16px;
}
.boutique-item-box {
  padding: 5px 0;
}
.boutique-img {
  width: 100%;
  height: 100%;
}
.boutique-img-box {
  width: 100%;
  height: 28vh;
}
.boutique-box {
  margin: 20px 0 50px 0;
  background-color: white;
}
.wind-vane {
  padding-bottom: 5px;
  font-weight: 600;
  font-size: 20px;
}

.recommend-book-classify {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 12px;
  color: rgb(160, 160, 160);
}
.recommend-book-name {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 14px;
}
.recommend-book-img-box {
  height: 60%;
}
.recommend-book-img {
  width: 100%;
  height: 100%;
  border-radius: 6px;
}
.recommend-box {
  width: 22%;
}
.recommend {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.ad-img {
  margin: 5px 0;
  width: 100%;
}
.to-order-img-box {
  padding: 10px 10px 0 10px;
}
.to-order-text {
  font-size: 12px;
}
.to-order-item {
  flex: 1;
  text-align: center;
}
.to-order-img {
  width: 40%;
  height: 100%;
}
.to-order-box {
  display: flex;
  justify-content: space-around;
  background-color: white;
  margin-bottom: 20px;
}
</style>
