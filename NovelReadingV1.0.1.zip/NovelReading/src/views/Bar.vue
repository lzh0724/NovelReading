<script setup>
import { ref } from "vue";

defineProps({
  msg: String,
});

const active = 0;

</script>

<template>
  <div id="Bar">
    <van-tabbar route v-model="active" v-if="$route.meta.showTab">
      <van-tabbar-item to="/" icon="home-o"> 首页 </van-tabbar-item>

      <van-tabbar-item to="/bookshelf" icon="search"> 书架 </van-tabbar-item>

      <van-tabbar-item to="/stack" icon="friends-o">书库 </van-tabbar-item>

      <van-tabbar-item to="/mine" icon="setting-o">我的 </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<style scoped>
</style>
