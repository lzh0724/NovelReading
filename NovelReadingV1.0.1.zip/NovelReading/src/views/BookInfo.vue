<script setup>
import { useRouter } from "vue-router";
import { inject, ref } from "vue";
import { onMounted, onBeforeMount, nextTick } from "vue";
const axios = inject("axios");
console.log(axios);
const router = useRouter();
defineProps({
  msg: String,
});
onBeforeMount(() => {
  // getBookInFo()
});
onMounted(() => {
  nextTick(() => {
    console.log(book_list);
  });
});
var book_list = ref([]);
var book_info = ref([]);
var recommend_list_1 = ref([]);
var recommend_list_2 = ref([]);
const ProduceRecommendList = (list) => {
  for (let i = 0; i < array.length; i++) {
    const element = array[i];
  }
};
const getBookInFo = () => {
  // 向给定ID的用户发起请求
  axios.get("../../public/json/book_list.json").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      console.log(data.data.books);
      book_list.value = data.data.books.books_list;
      book_info.value = book_list.value.find((object) => object.id === book_id);
      list.value = [...book_info.value.barrage];
    });
    nextTick(() => {
      recommend_list_1.value = data.data.books.recommend_list_1;
      recommend_list_2.value = data.data.books.recommend_list_2;
      console.log(recommend_list_2.value);
    });
  });
};
const active = 0;
console.log("获取到的参数", router.currentRoute.value.query.bookid);
const book_id = router.currentRoute.value.query.bookid;
getBookInFo();
const onClickLeft = () => {
  router.go(-1);
};
const icon_list = {
  collect_url: "../../public/icon/book-info-icon/collect.png",
  love_url: "../../public/icon/book-info-icon/love.png",
  popularity_url: "../../public/icon/book-info-icon/popularity.png",
  down_url: "../../public/icon/book-info-icon/down.png",
  top_url: "../../public/icon/book-info-icon/top.png",
  directory_url: "../../public/icon/book-info-icon/directory.png",
  right_url: "../../public/icon/book-info-icon/right.png",
};
var synopsis_img = ref(icon_list.down_url);
var synopsis_height = ref("50px");
const ToSearch = () => {
  router.push({ path: "/search" });
};
const SynopsisHeightChange = () => {
  if (synopsis_img.value === icon_list.down_url) {
    nextTick(() => {
      synopsis_img.value = "../../public/icon/book-info-icon/top.png";
      synopsis_height.value = "100%";
      console.log("展开");
    });
  } else {
    nextTick(() => {
      synopsis_img.value = icon_list.down_url;
      synopsis_height.value = "50px";
      console.log("关闭");
    });
  }
};
const defaultList = [
  { id: 100, text: "新水平" },
  { id: 101, text: "新境界" },
  { id: 102, text: "新举措" },
  { id: 103, text: "新发展" },
  { id: 104, text: "新突破" },
  { id: 105, text: "新成绩" },
  { id: 106, text: "新成效" },
  { id: 107, text: "重要性" },
  { id: 108, text: "紧迫性" },
  { id: 110, text: "自觉性" },
  { id: 111, text: "主动性" },
  { id: 112, text: "时代性" },
  { id: 113, text: "积极性" },
  { id: 114, text: "长期性" },
  { id: 115, text: "艰巨性" },
];

var list = ref([...defaultList]);
const add = () => {
  list.value.push({ id: Math.random(), text: "点一下，夏昕睿jj短1厘米" });
};
const ToBookInfo = (id) => {
  console.log(id);
  // books_list.find((object) => object.id === id)
  router.push({
    path: `/books/:id=${id}`,
    query: { bookid: id},
  });
  setTimeout(() => {
  router.go(0);
  }, 0);
};
setTimeout(() => {
  // document.getElementById("BookInfo").style.backgroundImage=`url(${book_info.url})`
}, 0);
console.log(book_list);
</script>

<template>
  <div class="blur-bckimg-box">
    <img class="blur-bckimg" :src="book_info.url" alt="" />
  </div>
  <div id="BookInfo">
    <van-nav-bar
      @click-left="onClickLeft"
      :title="book_info.name"
      left-text="返回"
      left-arrow
    >
      <template #right>
        <van-icon @click="ToSearch" name="search" size="18" />
      </template>
    </van-nav-bar>

    <div class="book-title-box">
      <div class="book-title">
        <div class="book-text-box">
          <div class="book-name">
            {{ book_info.name }}
          </div>
          <div class="book-classify">{{ book_info.classify }}</div>
          <div class="book-autor">
            <div class="autor-img-box">
              <img class="autor-img" :src="book_info.url" alt="" />
            </div>
            <div class="autor-name">
              {{ book_info.autorname }}
            </div>
          </div>
        </div>
        <div class="book-img-box">
          <img class="book-img" :src="book_info.autorurl" alt="" />
        </div>
      </div>
    </div>
    <div class="book_context-box">
      <div class="book_context">
        <div class="book-browse-box">
          <div class="book-browse">
            <div class="popularity-box">
              <div class="browse-number">
                {{ book_info.popularity }}
              </div>
              <div class="browse-img-box">
                人气
                <img
                  class="browse-img"
                  :src="icon_list.popularity_url"
                  alt=""
                />
              </div>
            </div>
            <div class="collect-box">
              <div class="browse-number">
                {{ book_info.collect }}
              </div>
              <div class="browse-img-box">
                收藏
                <img class="browse-img" :src="icon_list.collect_url" alt="" />
              </div>
            </div>
            <div class="love-box">
              <div class="browse-number">
                {{ book_info.love }}
              </div>
              <div class="browse-img-box">
                点赞 <img class="browse-img" :src="icon_list.love_url" alt="" />
              </div>
            </div>
          </div>
        </div>
        <div class="book-synopsis-box" @click="SynopsisHeightChange()">
          <div :style="{ height: synopsis_height }" class="book-synopsis">
            {{ book_info.synopsis }}
          </div>
          <div class="down-img-box">
            <img class="down-img" :src="synopsis_img" alt="" />
          </div>
        </div>
        <div class="book-directory-box">
          <div class="book-directory">
            <div class="directory-name">
              <img
                class="directory-icon"
                :src="icon_list.directory_url"
                alt=""
              />
              <div class="directory-name-text">
                {{ book_info.directory.name }}
              </div>
            </div>
            <div class="directory-time">
              {{ book_info.directory.time }}
              <!-- <img class="right-icon" :src="icon_list.right_url" alt=""> -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="barrage-box">
      <div class="barrage">
        <van-barrage v-model="list" duration="6000">
          <div class="video" style="width: 100%; height: 150px"></div>
        </van-barrage>
        <van-space style="margin-top: 10px">
          <van-button @click="add" type="primary" size="small">
            点击发送一条弹幕试试
          </van-button>
        </van-space>
      </div>
    </div>

    <div class="recommend-box">
      <div class="recommend">
        <div class="recommend-title">作品集</div>
        <div class="recommend-books-box">
          <div
            class="recommend-books"
            v-for="(item, index) in recommend_list_1"
            :key="index"
            @click="ToBookInfo(item.id)"

          >
            <div class="recommend-book-img-box">
              <img class="recommend-book-img" :src="item.url" alt="" />
            </div>
            <div class="recommend-book-name">
              {{ item.name }}
            </div>
          </div>
        </div>
      </div>
      <div class="recommend">
        <div class="recommend-title">你可能感兴趣的小说</div>
        <div class="recommend-books-box">
          <div
            class="recommend-books"
            v-for="(item, index) in recommend_list_2"
            :key="index"
            @click="ToBookInfo(item.id)"
          >
            <div class="recommend-book-img-box">
              <img class="recommend-book-img" :src="item.url" alt="" />
            </div>
            <div class="recommend-book-name">
              {{ item.name }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <van-action-bar>
      <van-action-bar-icon
        icon="../../public/icon/book-info-icon/down_directory.png"
        text="目录"
      />
      <van-action-bar-icon
        icon="../../public/icon/book-info-icon/down_down.png"
        text="下载"
      />
      <van-action-bar-button color="#be99ff" type="warning" text="收藏本书" />
      <van-action-bar-button color="#7232dd" type="danger" text="开始阅读" />
    </van-action-bar>
  </div>
</template>

<style scoped>
.recommend-books{
  flex:1;

}
.recommend-book-name {
  width: 80%;
  font-size: 14px;
  color: rgb(123, 123, 123);
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.recommend-book-img-box {
  width: 80%;
  height: 110px;
  overflow: hidden;
  border-radius: 12px;
}
.recommend-book-img {
  width: 100%;
}
.recommend-books-box {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}
.recommend-title {
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 1px;
}
.recommend {
  width: 90%;
  margin: auto;
}
.recommend-box {
  background-color: white;
  margin: 10px 0 50px 0;
  border-radius: 15px 15px 0 0;
  padding: 20px 0;
}
.video {
}

.barrage {
  width: 90%;
  margin: auto;
}
.barrage-box {
  background-color: white;
  margin-top: 10px;
  padding-bottom: 10px;
  border-radius: 0 0 20px 20px;
}
.directory-name-text {
  overflow: hidden;
}
.directory-time {
  flex: 1;
  text-align: right;
}
.directory-icon {
  width: 8%;
  margin-right: 8px;
}
.directory-name {
  flex: 3;
  width: 100%;
  display: flex;
}
.book-directory {
  display: flex;
  justify-content: space-between;
  color: rgb(120, 120, 120);
}
.book-directory-box {
  margin-top: 10px;
  padding-bottom: 10px;
}
.down-img {
  width: 100%;
}
.down-img-box {
  width: 5%;
  margin-left: auto;
}

.book-synopsis {
  color: rgb(120, 120, 120);
  letter-spacing: 0.5px;
  text-indent: 2em;
  overflow: hidden;
  height: 50px;
}
.browse-img {
  width: 14%;
  margin-left: 6px;
}
.browse-img-box {
  width: 100%;
  display: flex;
  align-items: center;
}
.browse-img-box {
  color: rgb(148, 148, 148);
}
.browse-number {
  font-weight: 700;
  font-size: 26px;
}
.book-browse {
  display: flex;
  justify-content: space-between;
}
.book-browse-box {
  padding: 20px 0;
}
.book_context {
  width: 90%;
  margin: auto;
}
.book_context-box {
  margin-top: 20px;
  background-color: white;
  border-radius: 20px 20px 0 0;
}
.autor-name {
  color: white;
  letter-spacing: 1px;
}
.book-classify {
  color: white;
  letter-spacing: 1px;
}
.book-autor {
  display: flex;
  align-items: center;
}
.book-img-box {
  flex: 2;
  height: 150px;
  overflow: hidden;
  border-radius: 10px;
}
.book-img {
  width: 100%;
}
.autor-img {
  width: 100%;
}
.autor-img-box {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 10px;
}
.book-name {
  font-size: 20px;
  color: white;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.book-text-box {
  flex: 3;
  margin-right: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.book-title {
  width: 90%;
  margin: 10px auto;
  display: flex;
  justify-content: space-between;
}
.book-title-box {
  background-color: rgba(255, 255, 255, 0) !important;
}
.blur-bckimg {
  width: 100%;
  position: relative;
  filter: blur(20px);
}
.blur-bckimg-box {
  width: 100%;
  height: 300px;
  position: absolute;
  overflow: hidden;
}
#BookInfo {
  position: absolute;
  z-index: 1;
}
</style>
