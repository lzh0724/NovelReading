<script setup>
import { ref,inject,nextTick,onMounted } from "vue";
import { showToast, closeToast, showLoadingToast } from "vant";
import { useRouter } from "vue-router";
const axios = inject("axios");
let is_Loading = ref(false);
onMounted(()=>{

})
defineProps({
  msg: String,
});
const label_list = [
  { name: "记录", url: "../../public/icon/history.png" },
  { name: "下载", url: "../../public/icon/download.png" },
  { name: "更多", url: "../../public/icon/more.png" },
];
const recommend_book = ref({
  name: "重生之成为韩溢洁的爹地",
  synopsis: "求求了，你们这些五十万不要再说了！",
  url: "../../public/book-img/book1.jpg",
});
const book_list = ref([]);
const onClickRight = () => showToast("按钮");
const router = useRouter();
const getBookInFo = () => {
  closeToast();

  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  // 向给定ID的用户发起请求
  axios.get("../../public/json/book_list.json").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      console.log(data.data.books);
      book_list.value = data.data.books.mine_books;
      console.log(111,book_list);
    });
    nextTick(()=>{
      recommend_book.value = data.data.books.books_list[Math.round(Math.random()*(data.data.books.books_list.length))];
      console.log(recommend_book.value);
  closeToast();

    });
  });
};
getBookInFo();
const ToBookInfo = (id) => {
  console.log(id);
  router.push({ path: `/books/:id=${id}`, query: { bookid: id } });
  setTimeout(() => {
    router.go(0);
  }, 0);
};
const ToStack = () => {
  router.push({ path: "/stack" });
};
</script>

<template>
  <div id="BookShelf">
    <div class="loading-box">
      <van-loading class="loading" v-show="is_Loading" type="spinner" color="#1989fa" />
    </div>
    <div class="title-box">
      <div class="title">
        <div class="title-text">书架</div>
        <div class="title-label-box">
          <div
            class="title-label"
            v-for="(item, index) in label_list"
            :key="index"
          >
            <img class="title-label-img" :src="item.url" alt="" />

            <div class="title-label-text">
              {{ item.name }}
            </div>
          </div>
        </div>
      </div>
      <div class="recommend-book-box">
        <div class="recommend-book">
          <img class="recommend-book-img" :src="recommend_book.url" alt="" />

          <div class="recommend-book-text">
            <div>编辑推荐</div>
            <div class="recommend-book-synopsis">
              <div class="recommend-book-synopsis-text">
                {{ recommend_book.synopsis }}
              </div>
            </div>
            <div class="recommend-book-name">
              <div class="recommend-book-name-text">
                《{{ recommend_book.name }}》
              </div>
            </div>
          </div>
          <div class="recommend-book-icon-box">
            <div class="recommend-book-love">
              <img
                class="recommend-book-icon"
                src="../../public/icon/love.png"
                alt=""
              />
              想看
            </div>
            <div class="recommend-book-sign">
              <img
                class="recommend-book-icon"
                src="../../public/icon/sign-in.png"
                alt=""
              />
              签到
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="bookshelf-box">
      <div class="bookshelf">
        <div
          class="my-book-box"
          v-for="(item, index) in book_list"
          :key="index"
          @click="ToBookInfo(item.id)"
        >
          <div class="my-book-img-box">
            <img class="my-book-img" :src="item.url" alt="" />
          </div>
          <div class="my-book-name">
            {{ item.name }}
          </div>
        </div>
        <div class="my-book-box">
          <div class="my-book-img-box">
            <img
              class="my-book-img"
              src="../../public/book-img/add-book.jpg"
              alt=""
              @click="ToStack"
            />
          </div>
          <div class="my-book-name"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.loading{
  
}
.loading-box{
  position:fixed;
  top: 50%;
  left: 50%;
  z-index: 10;
}
.my-book-img-box {
  height: 70%;
}
.add-book {
  width: 22%;
  border: 1px rgb(163, 163, 163) solid;
  border-radius: 4px;
}
.my-book-name {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 14px;
  letter-spacing: 1px;
  font-weight: 500;
}
.my-book-img {
  width: 100%;
  height: 100%;
  border-radius: 4px;
  border: 1px rgb(198, 198, 198) solid;
}
.my-book-box {
  width: 25%;
  margin: 20px 0 0 20px;
}
.bookshelf {
  min-height: 800px;
  display: flex;
  flex-wrap: wrap;
  align-content: baseline;
}
.bookshelf-box {
  background-color: white;
  border-radius: 30px 30px 0 0;
  padding-bottom: 20%;
}
.recommend-book-sign {
  background-color: rgb(254, 135, 155);
  border-radius: 20px;
  text-align: center;
  margin-top: 8px;
  padding: 4px 0;
  border: 2px white solid;
}
.recommend-book-love {
  background-color: rgb(254, 135, 155);
  border-radius: 20px;
  text-align: center;
  padding: 4px 0;
  border: 2px white solid;
}
.recommend-book-synopsis-text {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 16px;
  letter-spacing: 1px;
}
.recommend-book-icon {
  width: 20%;
  vertical-align: middle;
}
.recommend-book-icon-box {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  font-size: 16px;
  margin-left: 6px;
}
.recommend-book-text {
  flex: 2.5;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  padding-left: 10px;
}
.recommend-book-name {
  font-size: 12px;
  letter-spacing: 1px;
}
.recommend-book-synopsis {
}
.recommend-book-img {
  width: 20%;
  border-radius: 6px;
  flex: 1;
}
.recommend-book {
  display: flex;
  justify-content: space-between;
  width: 100%;
  font-size: 14px;
}
.recommend-book-box {
  color: white;
}
.title-label-text {
  font-size: 12px;
  font-weight: 600;
}
.title-label-img {
  width: 50%;
}
.title-label {
  width: 100%;
  text-align: center;
}
.title-label-box {
  flex: 2;

  display: flex;
  justify-content: space-between;
}
.title-text {
  font-size: 30px;
  font-weight: 600;
  flex: 4;
  letter-spacing: 2px;
}
.title {
  display: flex;
  align-items: center;
  margin: 0 auto;
  padding-bottom: 20px;
}
.title-box {
  color: rgb(255, 255, 255);
  padding: 16px 0 16px 0;
  margin: 0 20px 10px 20px;
}

#BookShelf {
  background-image: url("../../public/book-img/bck-img.jpg");
  width: 100%;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-size: 100% 100%;
}
</style>
