<script setup>
import { ref } from "vue";
import { showToast } from "vant";


let mp3 = new Audio("/public/video/原神，启动！.mp3"); // 创建音频对象
mp3.play(); // 播放


defineProps({
  msg: String,
});
const onClickRight = () => showToast("按钮");

</script>

<template>
  <div id="index">
    <van-nav-bar title="首页" right-text="按钮" @click-right="onClickRight" />
    
    
  </div>
</template>

<style scoped>

</style>
