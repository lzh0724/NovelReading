<script setup>
import { ref } from "vue";
import { showToast } from "vant";

defineProps({
  msg: String,
});
let music = document.getElementById("audio");
const user_info_list = {
  name: "三年级本科生",
  url: "../../public/book-img/book1.jpg",
  subscribe: 100,
  fans: 99,
  level: 100,
};
const mine_property_icon_list = [
  {
    name: "我的预约",
    url: "../../public/icon/reservation.png",
  },
  {
    name: "我的装扮",
    url: "../../public/icon/dress.png",
  },
  {
    name: "我的消息",
    url: "../../public/icon/message.png",
  },
  {
    name: "我的月票",
    url: "../../public/icon/ticket.png",
  },
  {
    name: "我的道具",
    url: "../../public/icon/prop.png",
  },
  {
    name: "成为作者",
    url: "../../public/icon/becomeauthor.png",
  },
  {
    name: "周边商城",
    url: "../../public/icon/hypermarket.png",
  },
  {
    name: "我的书单",
    url: "../../public/icon/booklist-2.png",
  },
];
const count = ref(0);
let mp3 = new Audio("/public/video/1.mp3"); // 创建音频对象

const ClickProperty = (name) => {
  console.log(name);
  showToast(name);
  mp3.play(); // 播放

};
</script>

<template>
  <div id="mine">
    <van-nav-bar title="我的">
      <template #right>
        <van-icon name="search" size="18" />
      </template>
    </van-nav-bar>

    <div class="user-info-box">
      <div class="user-img-box">
        <img class="user-img" :src="user_info_list.url" alt="" />
      </div>
      <div class="user-info-text">
        <div class="user-info-name">
          {{ user_info_list.name }}
        </div>
        <div class="user-info-orther-box">
          <div class="user-info-orther-text">
            {{ user_info_list.subscribe }}关注
          </div>
          <div class="user-info-orther-text">{{ user_info_list.fans }}粉丝</div>
          <div class="user-info-orther-text">Lv.{{ user_info_list.level }}</div>
        </div>
      </div>
    </div>

    <div class="mine-property-box">
      <div class="mine-property">
        <div
          class="property-box"
          v-for="(item, index) in mine_property_icon_list"
          :key="index"
          @click="ClickProperty(item.name)"
        >
          <div>
            <img class="property-img" :src="item.url" alt="" />
          </div>
          <div class="property-name">
            {{ item.name }}
          </div>
        </div>
      </div>
    </div>
    <audio id="audio" src="/public/video/1.mp3" preload>
      对不起，您的浏览器不支持HTML5音频播放。
    </audio>
  </div>
</template>
<style scoped>
.property-img {
  width: 50%;
}
.property-box {
  width: 20%;
  text-align: center;
  margin: 8px;
}
.mine-property {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  width: 90%;
  margin: auto;
  border-radius: 10px;
  background-color: white;
}
.mine-property-box {
  letter-spacing: 1px;
}
.user-info-orther-text {
  margin: 0 6px;
}
.user-info-orther-box {
  display: flex;
  justify-content: center;
  padding: 5px;
  padding-bottom: 10px;
}
.user-info-name {
  font-size: 20px;
  font-weight: 600;
}
.user-info-text {
  margin: auto;
  width: 90%;
  text-align: center;
  background-color: white;
  border-radius: 10px;
  padding-top: 40px;
}
.user-img {
  width: 66px;
  height: 66px;
  border-radius: 50%;
}
.user-img-box {
  position: absolute;
  text-align: center;
  width: 100%;
  top: 60px;
}
.user-info-box {
  margin: 50px 0 20px 0;
  letter-spacing: 1px;
}
.property-box:active {
  background-color: rgb(231, 231, 231);
}
#mine {
  background: linear-gradient(
    rgb(198, 75, 255) 0%,
    rgb(251, 139, 255) 40%,
    rgb(241, 241, 241) 80%
  );
}
</style>
