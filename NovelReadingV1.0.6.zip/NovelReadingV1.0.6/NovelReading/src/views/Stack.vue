<script setup>
import { ref, onMounted, nextTick } from "vue";
import { showToast, closeToast, showLoadingToast } from "vant";
import { useRouter } from "vue-router";
import swiper from "../components/swiper.vue";
import { inject } from "vue";
const axios = inject("axios");
let is_Loading = ref(false);

defineProps({
  msg: String,
});
const onClickRight = () => showToast("按钮");
const images = [
  "../../public/swiper-img/1.jpg",
  "../../public/swiper-img/2.jpg",
  "../../public/swiper-img/3.jpg",
];
const to_orther_list = [
  { name: "今日更新", url: "../../public/icon/renew.png" },
  { name: "精选专区", url: "../../public/icon/selected.png" },
  { name: "排行榜", url: "../../public/icon/ranking.png" },
  { name: "分类", url: "../../public/icon/classification.png" },
  { name: "书单", url: "../../public/icon/booklist.png" },
  { name: "日轻", url: "../../public/icon/book.png" },
];
const recommend_book_list = ref([]);
const boutique_book_list = [
  {
    id: 11,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/1.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
  {
    id: 12,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/2.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
  {
    id: 13,
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/swiper-img/3.jpg",
    classify: "异世界/无敌/日常",
    popularity: 1000,
  },
];
const router = useRouter();
const ToSearch = () => {
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  router.push({ path: "/search" });
};
const onClickLeft = () => {
  router.go(-1);
};
const ToBookInfo = (id) => {
  console.log(id);
  // books_list.find((object) => object.id === id)
  console.log(books_list);
  router.push({
    path: `/books/:id=${id}`,
    query: { bookid: id },
  });
  setTimeout(() => {
    router.go(0);
    closeToast();
    showLoadingToast({
      message: "加载中...",
      forbidClick: true,
    });
  }, 0);
};
const solicitation_book_list = ref([
  {
    id: "0",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "1",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "2",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
  {
    id: "3",
    name: "重生之不得不成为韩溢洁的爸爸",
    url: "../../public/book-img/book1.jpg",
    classify: "异世界/无敌/日常",
  },
]);
var books_list = ref([]);
const getBookInFo = () => {
  // 向给定ID的用户发起请求
  closeToast();
  showLoadingToast({
    message: "加载中...",
    forbidClick: true,
  });
  axios.get("../../public/json/book_list.json").then(function (data) {
    // 处理成功情况
    nextTick(() => {
      recommend_book_list.value = [];
      books_list.value = data.data.books.books_list;
      for (let index = 0; index < 8; index++) {
        if (data.data.books.books_list[index] !== undefined) {
          recommend_book_list.value.push(data.data.books.books_list[index]);
        }
        ReplaceSolicitation();
      }
      closeToast();
    });
  });
};
getBookInFo();
const ReplaceSolicitation = () => {
  solicitation_book_list.value = [];
  for (let index = 0; index < 4; index++) {
    if (books_list.value[index] !== undefined) {
      var i = Math.round(Math.random() * (books_list.value.length - 1));
      if (i < 0) {
        i = 0;
      }
      if (solicitation_book_list.value.indexOf(books_list.value[i]) === -1) {
        solicitation_book_list.value.push(books_list.value[i]);
      } else {
        index--;
      }
    }
  }
};

onMounted(() => {
  nextTick(() => {
    console.log(books_list);
    closeToast();
  });
});
// ref(swiperChange)
</script>

<template>
  <div id="stack">
    <div class="loading-box">
      <van-loading
        class="loading"
        v-show="is_Loading"
        type="spinner"
        color="#1989fa"
      />
    </div>
    <van-nav-bar title="书库">
      <template #right>
        <van-icon @click="ToSearch" name="search" size="18" />
      </template>
    </van-nav-bar>
    <swiper :swiper_img_list="images"></swiper>
    <div class="to-order-box">
      <div
        class="to-order-item"
        v-for="(item, index) in to_orther_list"
        :key="index"
      >
        <div class="to-order-img-box">
          <img class="to-order-img" :src="item.url" alt="" />
        </div>
        <div class="to-order-text">
          {{ item.name }}
        </div>
      </div>
    </div>

    <div style="background-color: white; border-radius: 26px 26px 0 0">
      <div style="padding: 0 10px 10px 10px; min-height: 520px">
        <div>
          <img class="ad-img" src="../../public/book-img/ad.jpg" alt="" />
        </div>
        <div class="wind-vane">人气风向标</div>
        <div class="recommend">
          <div
            class="recommend-box"
            @click="ToBookInfo(item.id)"
            v-for="(item, index) in recommend_book_list"
            :key="index"
          >
            <div class="recommend-book-img-box">
              <img class="recommend-book-img" :src="item.url" alt="" />
            </div>
            <div class="recommend-book-name">
              {{ item.name }}
            </div>
            <div class="recommend-book-classify">
              {{ item.classify }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="solicitation-box">
      <div class="solicitation">
        <div class="solicitation-title">征文推荐</div>
        <div class="solicitation-book-box">
          <div
            class="solicitation-book"
            v-for="(item, index) in solicitation_book_list"
            :key="index"
            @click="ToBookInfo(item.id)"
          >
            <div class="solicitation-img-box">
              <img class="solicitation-img" :src="item.url" alt="" />
            </div>
            <div class="solicitation-book-name">
              {{ item.name }}
            </div>
            <div class="solicitation-book-classify">
              {{ item.classify }}
            </div>
          </div>
        </div>
        <div class="solicitation-button-box">
          <van-button
            @click="ReplaceSolicitation()"
            size="large"
            class="solicitation-button"
            >换一换</van-button
          >
        </div>
      </div>
    </div>

    <div>
      <div class="boutique-box">
        <div class="boutique-title">今日精品更新</div>
        <div
          class="boutique-item-box"
          v-for="(item, index) in boutique_book_list"
          :key="index"
          @click="ToBookInfo(item.id)"
        >
          <div class="boutique-img-box">
            <img class="boutique-img" :src="item.url" alt="" />
          </div>
          <div class="boutique-item">
            <div class="boutique-line">
              <span class="boutique-name">
                {{ item.name }}
              </span>
              <span class="boutique-popularity">
                人气：{{ item.popularity }}W+
              </span>
            </div>

            <div class="boutique-classify">
              {{ item.classify }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.loading-box {
  position: fixed;
  top: 50%;
  left: 50%;
  z-index: 10;
}
.solicitation-button {
  color: rgb(246, 72, 49);
  font-weight: 600;
  font-size: 18px;
}
.solicitation-book-classify {
  margin-top: 10px;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
}
.solicitation-book-name {
  margin-top: 8px;
  height: 42px;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 14px;
}
.solicitation-img-box {
  width: 100%;
  height: 90px;
  border-radius: 6px;
  overflow: hidden;
}
.solicitation-img {
  width: 100%;
  transition: all 0.5s ease-in-out;
}
.solicitation-book {
  flex: 1;
  margin: 5px 5px 5px 0;
}
.solicitation-book-box {
  display: flex;
}
.solicitation-title {
  font-size: 22px;
  letter-spacing: 1px;
}
.solicitation {
  width: 90%;
  margin: 10px auto;
  padding: 20px 0;
  color: white;
}
.solicitation-box {
  border-radius: 15px;
  background-color: #282828;
}
.boutique-title {
  width: 90%;
  margin: 0px auto;
  padding: 15px 0 10px 0;
  font-size: 20px;
  font-weight: 800;
  letter-spacing: 2px;
}
.boutique-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 6px;
}
.boutique-classify {
  font-size: 12px;
  color: rgb(143, 143, 143);
  padding-top: 10px;
}
.boutique-item {
  width: 90%;
  margin: 0 auto;
}
.boutique-popularity {
  font-size: 12px;
  color: rgb(143, 143, 143);
}
.boutique-name {
  font-size: 16px;
}
.boutique-item-box {
  padding: 5px 0;
}
.boutique-img {
  width: 100%;
  height: 100%;
}
.boutique-img-box {
  width: 100%;
  height: 28vh;
}
.boutique-box {
  margin: 20px 0 50px 0;
  background-color: white;
}
.wind-vane {
  padding-bottom: 5px;
  font-weight: 600;
  font-size: 20px;
}

.recommend-book-classify {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 12px;
  color: rgb(160, 160, 160);
}
.recommend-book-name {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  display: -moz-box;
  -moz-line-clamp: 2;
  -moz-box-orient: vertical;
  overflow-wrap: break-word;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  font-size: 14px;
  height: 42px;
}
.recommend-book-img-box {
  height: 60%;
}
.recommend-book-img {
  width: 100%;
  height: 100%;
  border-radius: 6px;
}
.recommend-box {
  width: 22%;
}
.recommend {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.ad-img {
  margin: 5px 0;
  width: 100%;
}
.to-order-img-box {
  padding: 10px 10px 0 10px;
}
.to-order-text {
  font-size: 12px;
}
.to-order-item {
  flex: 1;
  text-align: center;
}
.to-order-img {
  width: 40%;
  height: 100%;
}
.to-order-box {
  display: flex;
  justify-content: space-around;
  background-color: white;
  margin-bottom: 20px;
}
</style>
